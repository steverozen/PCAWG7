library(testthat)
library(PCAWG7)

test_check("PCAWG7")

